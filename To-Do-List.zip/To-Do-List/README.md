# To-Do-List
The project called "To-Do List" is a web application that enables users to efficiently organize and handle their task lists. Developed with HTML, CSS and JavaScript this application offers an user friendly interface, for adding, managing and marking tasks as completed.
